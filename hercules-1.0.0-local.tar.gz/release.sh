#!/bin/bash

# Цвета
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Конфигурация
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$1"
MODE="$2"

if [ -z "$VERSION" ]; then
    echo -e "${YELLOW}Введите версию релиза:${NC}"
    read -r VERSION
fi

if [ -z "$MODE" ]; then
    echo -e "${YELLOW}Выберите режим (local/global):${NC}"
    read -r MODE
fi

RELEASE_BRANCH="release/${VERSION}"

# 1. Запускаем сборку
log_info "Запуск сборки..."
./build.sh "$VERSION" "$MODE"
if [ $? -ne 0 ]; then
    log_error "Ошибка сборки"
    exit 1
fi

# 2. Сохраняем текущую ветку
CURRENT_BRANCH=$(git branch --show-current)
log_info "Текущая ветка: ${CURRENT_BRANCH}"

# 3. Создаем или переключаемся на релизную ветку
if git show-ref --verify --quiet "refs/heads/${RELEASE_BRANCH}"; then
    log_info "Переключение на существующую ветку ${RELEASE_BRANCH}"
    git checkout "${RELEASE_BRANCH}"
else
    log_info "Создание новой ветки ${RELEASE_BRANCH}"
    git checkout -b "${RELEASE_BRANCH}"
fi

# 4. Копируем архив
ARCHIVE_NAME="hercules-${VERSION}-${MODE}.tar.gz"
if [ -f "${SCRIPT_DIR}/${ARCHIVE_NAME}" ]; then
    cp "${SCRIPT_DIR}/${ARCHIVE_NAME}" .
    log_success "Архив скопирован: ${ARCHIVE_NAME}"
else
    log_error "Архив не найден: ${ARCHIVE_NAME}"
    exit 1
fi

# 5. Копируем информацию о релизе
if [ -f "${SCRIPT_DIR}/LATEST_RELEASE.json" ]; then
    cp "${SCRIPT_DIR}/LATEST_RELEASE.json" .
    log_success "LATEST_RELEASE.json скопирован"
fi

# 6. Создаем README для релиза
cat > "RELEASE_${VERSION}.md" << EOF
# Релиз ${VERSION} (${MODE})

## Дата
$(date '+%Y-%m-%d %H:%M:%S')

## Режим сборки
${MODE^^}

## Содержимое
- Архив: ${ARCHIVE_NAME}
- Размер: $(du -h "${ARCHIVE_NAME}" | cut -f1)

## Описание
$([ "$MODE" = "local" ] && echo "LOCAL режим: сборка без main.html и исключенных файлов" || echo "GLOBAL режим: полная сборка со всеми файлами")

## Установка
\`\`\`bash
tar -xzf ${ARCHIVE_NAME}
cd build
# Далее следуйте инструкции
\`\`\`
EOF

git add "RELEASE_${VERSION}.md"

# 7. Коммитим
git add "${ARCHIVE_NAME}" "LATEST_RELEASE.json"
git commit -m "Release ${VERSION} (${MODE})

Архив: ${ARCHIVE_NAME}
Режим: ${MODE}
Версия: ${VERSION}"

# 8. Отправляем в remote
log_info "Отправка в remote..."
git push origin "${RELEASE_BRANCH}"

if [ $? -eq 0 ]; then
    log_success "Релиз успешно отправлен в ветку ${RELEASE_BRANCH}"
else
    log_error "Ошибка отправки в remote"
    exit 1
fi

# 9. Создаем Pull Request (опционально)
echo ""
echo -e "${YELLOW}Создать Pull Request в main? (y/n)${NC}"
read -r CREATE_PR

if [ "$CREATE_PR" = "y" ]; then
    if command -v gh &> /dev/null; then
        gh pr create \
            --title "Release ${VERSION}" \
            --body "Релиз версии ${VERSION} (${MODE} режим)" \
            --base main \
            --head "${RELEASE_BRANCH}"
        log_success "Pull Request создан"
    else
        log_warning "GitHub CLI не установлен. Создайте PR вручную:"
        echo "https://github.com/$(git remote get-url origin | sed 's/.*:\(.*\)\.git/\1/')/compare/main...${RELEASE_BRANCH}"
    fi
fi

# 10. Возвращаемся в исходную ветку
git checkout "${CURRENT_BRANCH}"
log_success "Возврат в ветку ${CURRENT_BRANCH}"

echo ""
echo "========================================="
echo -e "${GREEN}РЕЛИЗ ЗАВЕРШЕН${NC}"
echo "========================================="
echo -e "Ветка: ${BLUE}${RELEASE_BRANCH}${NC}"
echo -e "Архив: ${BLUE}${ARCHIVE_NAME}${NC}"
echo "========================================="